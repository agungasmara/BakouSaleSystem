@extends('frontend.layout.layout')
@section('content')

    <div id="root_frontend">
        <router-view class="view"></router-view>
    </div>

@endsection
