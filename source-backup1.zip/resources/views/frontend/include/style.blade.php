<!-- Bootstrap core CSS -->
    <link href="{{url('assets/frontend/bootstrap/css/bootstrap.css')}}" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="{{url('assets/frontend/css/style.css')}}" rel="stylesheet">

     <!-- styles needed by smoothproducts.js for product zoom  -->
    <link rel="stylesheet" href="{{url('assets/frontend/plugins/smoothproducts-master/css/smoothproducts.css')}}">
    <link href="{{url('assets/frontend/plugins/rating/bootstrap-rating.css')}}" rel="stylesheet">


    <!-- styles needed by footable  -->
    <link href="{{url('assets/frontend/css/footable-0.1.css')}}" rel="stylesheet" type="text/css"/>
    <link href="{{url('assets/frontend/css/footable.sortable-0.1.css')}}" rel="stylesheet" type="text/css"/>

     <link href="assets/css/ion.checkRadio.css" rel="stylesheet">
    <link href="assets/css/ion.checkRadio.cloudy.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="assets/css/jquery.minimalect.min.css" media="screen"/>
