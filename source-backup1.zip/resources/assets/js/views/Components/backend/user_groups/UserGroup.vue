<template>
	<section id ="content">
		<router-view></router-view>
	</section>
</template>