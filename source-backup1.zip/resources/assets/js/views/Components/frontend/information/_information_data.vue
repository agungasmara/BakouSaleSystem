<template>
	<div>testing</div>
</template>

<script type="text/javascript">
	export default{}
</script>