export default{
	thClassValue: function (id) {
	    var value = ['Templatesdropdown'+id]
	    return value.join(' ')
	},

	functionTest: function (price) {
		return price + '%%%%'
	}	

}