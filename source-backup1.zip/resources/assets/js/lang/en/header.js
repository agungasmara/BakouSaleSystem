es_DO: {
    'My Account': 'My Account',
    'How are you?': 'Como estás?'
}