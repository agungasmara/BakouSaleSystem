<?php

return [

   'you_may_also_like' => 'YOU MAY ALSO LIKE',
   'add_to_cart' => 'Add to Cart',
   'add_to_wishlist' => 'Add to Wishlist',
   'quantity' => 'Quantity',
   'size' => 'Size'
];
