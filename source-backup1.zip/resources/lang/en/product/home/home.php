<?php

return [

   'shop_now' => 'SHOP NOW'
];
