<?php

return [

   'cart' => 'CART',
   'view_cart' => 'VIEW CART',
   'sup_total' => 'SUB TOTAL:',
   'check_out' => 'CHECK OUT',
   'help' => 'HELP',
   'my_account' => 'MY ACCOUNT',
   'sign_in' => 'SIGN IN',
   'create_account' => 'CREATE ACCOUNT',
   'login_to_tshop' => 'Login to TSHOP',
   'enter_username'  => 'Enter Username',
   'password'  => 'Password',
   'remember_me'  => 'Remember Me',
   'register' => 'REGISTER',
   'signup_with_facebook' => 'SIGNUP WITH FACEBOOK',
   'enter_email' => 'Enter Email',
];
