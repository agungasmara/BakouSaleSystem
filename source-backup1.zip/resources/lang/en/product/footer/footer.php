<?php

return [

   'support' => 'SUPPORT',
   'my_account' => 'My Account',
   'stay_in_touch' => 'STAY IN TOUCH',
   'subscribe' => 'Subscribe',
   'email' => 'E-mail'
];
	