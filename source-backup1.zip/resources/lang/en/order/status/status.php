<?php

return [

   'add_to_cart_btn' => 'Add to cart',
   'quick_view' => 'Quick View'
];
