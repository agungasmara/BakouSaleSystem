<?php

namespace App\Http\Models\BackEnd\Stock;

use Illuminate\Database\Eloquent\Model;

class Stock extends Model
{
    //
}
