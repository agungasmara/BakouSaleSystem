<?php

namespace App\Http\Models\BackEnd\Currency;

use Illuminate\Database\Eloquent\Model;

class Currency extends Model
{
    //
}
