<?php

namespace App\Http\Models\BackEnd\Measure;

use Illuminate\Database\Eloquent\Model;

class Measure extends Model
{
    //
}
