<?php

namespace App\Http\Models\BackEnd\Tax;

use Illuminate\Database\Eloquent\Model;

class Tax extends Model
{
    //
}
