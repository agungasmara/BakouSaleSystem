<?php

namespace App\Http\Controllers\Backend\Taxs;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class TaxsController extends Controller
{
    //
}
