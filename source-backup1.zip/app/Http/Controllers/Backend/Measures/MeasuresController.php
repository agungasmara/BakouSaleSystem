<?php

namespace App\Http\Controllers\Backend\Measures;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class MeasuresController extends Controller
{
    public function list()
    {

    }
    public function getPermission()
    {

    }
    public function store(Request $request)
    {

    }
    public function getUserByID($id)
    {

    }
    public function update(Request $request,$id)
    {

    }
    public function destroy($id)
    {
    	
    }
}
