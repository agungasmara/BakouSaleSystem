<?php

namespace App\Http\Controllers\Backend\Stocks;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class StocksController extends Controller
{
    //
}
