<?php

namespace App\Http\Controllers\FrontEnd\Design;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
class CommonController extends Controller
{
    //
    public function getBanner(){
    	return "HellowroldBanner";
    }
}
